package com.hcl.loginproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginprojectApplication.class, args);
	}

}
