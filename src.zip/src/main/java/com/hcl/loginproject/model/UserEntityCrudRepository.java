package com.hcl.loginproject.model;

import org.springframework.data.repository.CrudRepository;

public interface UserEntityCrudRepository extends CrudRepository<UserEntity, Long> {

}
